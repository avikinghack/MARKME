import 'package:flutter/material.dart';

class StudentTile extends StatelessWidget {
  final String name;
  final bool isPresent;
  final VoidCallback? onTap;

  const StudentTile({
    super.key,
    required this.name,
    required this.isPresent,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        title: Text(name),
        trailing: Text(
          isPresent ? "Present" : "Absent",
          style: TextStyle(
            color: isPresent ? Colors.green : Colors.red,
            fontWeight: FontWeight.bold,
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}
