import '../models/student_model.dart';
import 'firebase_service.dart';

class StudentService {
  static Future addStudent(StudentModel student) async {
    await FirebaseService.db.collection('students').add(student.toMap());
  }

  static Future<List<StudentModel>> getStudents() async {
    var snapshot = await FirebaseService.db.collection('students').get();

    return snapshot.docs.map((doc) {
      return StudentModel.fromMap(doc.data(), doc.id);
    }).toList();
  }

  static Future deleteStudent(String id) async {
    await FirebaseService.db.collection('students').doc(id).delete();
  }
}
