import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/class_model.dart';

class ClassListScreen extends StatefulWidget {
  const ClassListScreen({super.key});

  @override
  State<ClassListScreen> createState() => _ClassListScreenState();
}

class _ClassListScreenState extends State<ClassListScreen> {
  List<ClassModel> classes = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchClasses();
  }

  Future<void> fetchClasses() async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection('classes')
          .get();

      classes = snapshot.docs.map((doc) {
        return ClassModel.fromMap(doc.data(), doc.id);
      }).toList();
    } catch (e) {
      print("Error fetching classes: $e");
    }

    setState(() {
      isLoading = false;
    });
  }

  void openClass(ClassModel cls) {
    // You can navigate to attendance or student list
    Navigator.pushNamed(context, '/attendance', arguments: cls.id);
  }

  void deleteClass(String id) async {
    await FirebaseFirestore.instance.collection('classes').doc(id).delete();
    fetchClasses(); // refresh list
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("My Classes")),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : classes.isEmpty
          ? const Center(child: Text("No classes created"))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: classes.length,
              itemBuilder: (context, index) {
                final cls = classes[index];

                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    title: Text(
                      cls.className,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      "${cls.branch} - ${cls.section}\nLecture: ${cls.lectureNo}",
                    ),
                    isThreeLine: true,
                    trailing: PopupMenuButton(
                      itemBuilder: (context) => [
                        const PopupMenuItem(value: 'open', child: Text("Open")),
                        const PopupMenuItem(
                          value: 'delete',
                          child: Text("Delete"),
                        ),
                      ],
                      onSelected: (value) {
                        if (value == 'open') {
                          openClass(cls);
                        } else if (value == 'delete') {
                          deleteClass(cls.id);
                        }
                      },
                    ),
                  ),
                );
              },
            ),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, '/createClass');
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
