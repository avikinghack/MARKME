import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData lightTheme = ThemeData(
    scaffoldBackgroundColor: Color(0xFFF5F7FB),
    primaryColor: Color(0xFF4F46E5),
    fontFamily: 'Roboto',
  );
}
