class StudentModel {
  String id;
  String name;
  String className;
  String branch;
  String scholarNo;
  String enrollmentNo;
  String studentPhone;
  String parentPhone;
  String? imagePath;

  StudentModel({
    required this.id,
    required this.name,
    required this.className,
    required this.branch,
    required this.scholarNo,
    required this.enrollmentNo,
    required this.studentPhone,
    required this.parentPhone,
    this.imagePath,
  });

  // Convert to Map (for Firebase)
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'class': className,
      'branch': branch,
      'scholarNo': scholarNo,
      'enrollmentNo': enrollmentNo,
      'studentPhone': studentPhone,
      'parentPhone': parentPhone,
      'imagePath': imagePath,
    };
  }

  // Convert from Firebase
  factory StudentModel.fromMap(Map<String, dynamic> map, String id) {
    return StudentModel(
      id: id,
      name: map['name'] ?? '',
      className: map['class'] ?? '',
      branch: map['branch'] ?? '',
      scholarNo: map['scholarNo'] ?? '',
      enrollmentNo: map['enrollmentNo'] ?? '',
      studentPhone: map['studentPhone'] ?? '',
      parentPhone: map['parentPhone'] ?? '',
      imagePath: map['imagePath'],
    );
  }
}
