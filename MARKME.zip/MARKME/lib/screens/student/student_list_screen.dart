import 'package:flutter/material.dart';

import '../../service/student_service.dart';
import '../../widgets/student_title.dart';

class StudentListScreen extends StatefulWidget {
  const StudentListScreen({super.key});

  @override
  State<StudentListScreen> createState() => _StudentListScreenState();
}

class _StudentListScreenState extends State<StudentListScreen> {
  List students = [];

  @override
  void initState() {
    load();
    super.initState();
  }

  void load() async {
    students = await StudentService.getStudents();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Students")),
      body: ListView(
        children: students.map((s) {
          return StudentTile(name: s.name, isPresent: false);
        }).toList(),
      ),
    );
  }
}
