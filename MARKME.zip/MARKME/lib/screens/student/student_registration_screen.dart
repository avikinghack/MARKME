import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../models/student_model.dart';
import '../../service/face_detection_service.dart';
import '../../utils/validators.dart';
import '../../widgets/custom_input.dart';
import '../../widgets/premium_button.dart';

class StudentService {
  static Future<void> addStudent(StudentModel student) async {
    await Future.delayed(Duration.zero);
  }
}

class StudentRegistrationScreen extends StatefulWidget {
  const StudentRegistrationScreen({super.key});

  @override
  State<StudentRegistrationScreen> createState() =>
      _StudentRegistrationScreenState();
}

class _StudentRegistrationScreenState extends State<StudentRegistrationScreen> {
  final name = TextEditingController();
  final className = TextEditingController();
  final branch = TextEditingController();
  final section = TextEditingController();
  final scholar = TextEditingController();
  final enroll = TextEditingController();
  final studentPhone = TextEditingController();
  final parentPhone = TextEditingController();

  File? image;
  bool isFaceValid = false;
  bool isLoading = false;

  // 📸 Capture image
  Future captureImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.camera);

    if (picked != null) {
      File img = File(picked.path);

      bool result = await FaceDetectionService.detectFaceWithEyes(img);

      if (result) {
        setState(() {
          image = img;
          isFaceValid = true;
        });

        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text("Face & Eyes Verified ✅")));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Face not valid ❌ Try again")),
        );
      }
    }
  }

  // 💾 Save student
  Future saveStudent() async {
    if (name.text.isEmpty ||
        className.text.isEmpty ||
        branch.text.isEmpty ||
        section.text.isEmpty) {
      showError("Please fill all fields");
      return;
    }

    if (Validators.validatePhone(studentPhone.text) != null ||
        Validators.validatePhone(parentPhone.text) != null) {
      showError("Invalid phone numbers");
      return;
    }

    if (studentPhone.text == parentPhone.text) {
      showError("Student & Parent number must be different");
      return;
    }

    if (image == null || !isFaceValid) {
      showError("Capture valid face first");
      return;
    }

    setState(() => isLoading = true);

    StudentModel student = StudentModel(
      id: "",
      name: name.text,
      className: className.text,
      branch: branch.text,
      scholarNo: scholar.text,
      enrollmentNo: enroll.text,
      studentPhone: studentPhone.text,
      parentPhone: parentPhone.text,
      imagePath: image!.path,
    );

    await StudentService.addStudent(student);

    setState(() => isLoading = false);

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text("Student Registered ✅")));

    Navigator.pop(context);
  }

  void showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Student Registration")),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),

        child: Column(
          children: [
            CustomInput(hint: "Name", controller: name),
            CustomInput(hint: "Class", controller: className),
            CustomInput(hint: "Branch", controller: branch),
            CustomInput(hint: "Section", controller: section),
            CustomInput(hint: "Scholar No", controller: scholar),
            CustomInput(hint: "Enrollment No", controller: enroll),

            CustomInput(
              hint: "Student Phone",
              controller: studentPhone,
              keyboardType: TextInputType.phone,
            ),

            CustomInput(
              hint: "Parent Phone",
              controller: parentPhone,
              keyboardType: TextInputType.phone,
            ),

            const SizedBox(height: 20),

            PremiumButton(title: "Capture Face", onTap: captureImage),

            const SizedBox(height: 10),

            if (image != null)
              Column(
                children: [
                  Image.file(image!, height: 120),
                  Text(
                    isFaceValid ? "Verified ✅" : "Invalid ❌",
                    style: TextStyle(
                      color: isFaceValid ? Colors.green : Colors.red,
                    ),
                  ),
                ],
              ),

            const SizedBox(height: 20),

            isLoading
                ? const CircularProgressIndicator()
                : PremiumButton(title: "Register Student", onTap: saveStudent),
          ],
        ),
      ),
    );
  }
}

class detectFaceWithEyes {}
