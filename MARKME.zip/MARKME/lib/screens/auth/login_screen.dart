import 'package:flutter/material.dart';
import 'package:markme/service/auth_service.dart';
import 'package:markme/widgets/custom_input.dart';
import 'package:markme/widgets/premium_button.dart';

class LoginScreen extends StatelessWidget {
  final email = TextEditingController();
  final password = TextEditingController();

  LoginScreen({super.key});

  void login(BuildContext context) async {
    var user = await AuthService.login(email.text, password.text);
    if (user != null) {
      Navigator.pushReplacementNamed(context, '/dashboard');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("MarkMe Login", style: TextStyle(fontSize: 24)),
            CustomInput(hint: "Email", controller: email),
            SizedBox(height: 10),
            CustomInput(
              hint: "Password",
              controller: password,
              isPassword: true,
            ),
            SizedBox(height: 20),
            PremiumButton(title: "Login", onTap: () => login(context)),
          ],
        ),
      ),
    );
  }
}
