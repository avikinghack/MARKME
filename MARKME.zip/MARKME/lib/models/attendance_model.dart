class AttendanceModel {
  String id;
  String studentId;
  String studentName;
  String classId;
  String status;
  DateTime date;

  AttendanceModel({
    required this.id,
    required this.studentId,
    required this.studentName,
    required this.classId,
    required this.status,
    required this.date,
  });

  Map<String, dynamic> toMap() {
    return {
      'studentId': studentId,
      'studentName': studentName,
      'classId': classId,
      'status': status,
      'date': date.toIso8601String(),
    };
  }

  factory AttendanceModel.fromMap(Map<String, dynamic> map, String id) {
    return AttendanceModel(
      id: id,
      studentId: map['studentId'] ?? '',
      studentName: map['studentName'] ?? '',
      classId: map['classId'] ?? '',
      status: map['status'] ?? '',
      date: DateTime.parse(map['date']),
    );
  }
}
