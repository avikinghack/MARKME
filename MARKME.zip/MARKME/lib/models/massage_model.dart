class MessageModel {
  String id;
  String message;
  String parentPhone;
  DateTime time;

  MessageModel({
    required this.id,
    required this.message,
    required this.parentPhone,
    required this.time,
  });

  Map<String, dynamic> toMap() {
    return {
      'message': message,
      'parentPhone': parentPhone,
      'time': time.toIso8601String(),
    };
  }

  factory MessageModel.fromMap(Map<String, dynamic> map, String id) {
    return MessageModel(
      id: id,
      message: map['message'] ?? '',
      parentPhone: map['parentPhone'] ?? '',
      time: DateTime.parse(map['time']),
    );
  }
}
