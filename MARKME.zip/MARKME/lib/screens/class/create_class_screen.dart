import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CreateClassScreen extends StatelessWidget {
  final className = TextEditingController();
  final branch = TextEditingController();
  final section = TextEditingController();
  final lecture = TextEditingController();

  CreateClassScreen({super.key});

  void create() async {
    await FirebaseFirestore.instance.collection('classes').add({
      'className': className.text,
      'branch': branch.text,
      'section': section.text,
      'lecture': lecture.text,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Create Class")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: className,
              decoration: InputDecoration(labelText: "Class"),
            ),
            TextField(
              controller: branch,
              decoration: InputDecoration(labelText: "Branch"),
            ),
            TextField(
              controller: section,
              decoration: InputDecoration(labelText: "Section"),
            ),
            TextField(
              controller: lecture,
              decoration: InputDecoration(labelText: "Lecture"),
            ),
            ElevatedButton(onPressed: create, child: Text("Create")),
          ],
        ),
      ),
    );
  }
}
