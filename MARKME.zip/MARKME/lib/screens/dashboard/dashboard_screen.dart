import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Dashboard")),
      body: ListView(
        padding: EdgeInsets.all(20),
        children: [
          ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, '/createClass'),
            child: Text("Create Class"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, '/registerStudent'),
            child: Text("Register Student"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, '/attendance'),
            child: Text("Take Attendance"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, '/reports'),
            child: Text("Reports"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, '/messages'),
            child: Text("Messages"),
          ),
        ],
      ),
    );
  }
}
