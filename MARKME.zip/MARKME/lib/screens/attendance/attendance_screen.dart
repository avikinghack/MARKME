import 'package:flutter/material.dart';

import '../../models/attendance_model.dart';
import '../../service/attendance_service.dart';
import '../../service/student_service.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  List students = [];

  @override
  void initState() {
    load();
    super.initState();
  }

  void load() async {
    students = await StudentService.getStudents();
    setState(() {});
  }

  void mark(String id, String name) async {
    await AttendanceService.markAttendance(
      AttendanceModel(
        id: "",
        studentId: id,
        studentName: name,
        classId: "1",
        status: "present",
        date: DateTime.now(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Attendance")),
      body: ListView(
        children: students.map((s) {
          return ListTile(
            title: Text(s.name),
            trailing: ElevatedButton(
              onPressed: () => mark(s.id, s.name),
              child: Text("Present"),
            ),
          );
        }).toList(),
      ),
    );
  }
}
