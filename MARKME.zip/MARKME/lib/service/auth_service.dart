import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_service.dart';

class AuthService {
  static Future<User?> login(String email, String password) async {
    try {
      var result = await FirebaseService.auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return result.user;
    } catch (e) {
      print("Login Error: $e");
      return null;
    }
  }

  static Future<User?> register(String email, String password) async {
    try {
      var result = await FirebaseService.auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      return result.user;
    } catch (e) {
      print("Register Error: $e");
      return null;
    }
  }

  static Future logout() async {
    await FirebaseService.auth.signOut();
  }
}
