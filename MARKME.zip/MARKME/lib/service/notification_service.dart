import 'firebase_service.dart';

class NotificationService {
  static Future sendAbsentNotification({
    required String name,
    required String className,
    required String lectureNo,
    required String parentPhone,
  }) async {
    String message =
        """
Your child $name is absent in $className 
(lecture $lectureNo).

Please ensure attendance.
""";

    await FirebaseService.db.collection('messages').add({
      'message': message,
      'parentPhone': parentPhone,
      'time': DateTime.now().toIso8601String(),
    });
  }
}
