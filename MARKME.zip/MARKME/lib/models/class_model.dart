class ClassModel {
  String id;
  String className;
  String branch;
  String section;
  String lectureNo;
  String teacherName;

  ClassModel({
    required this.id,
    required this.className,
    required this.branch,
    required this.section,
    required this.lectureNo,
    required this.teacherName,
  });

  Map<String, dynamic> toMap() {
    return {
      'className': className,
      'branch': branch,
      'section': section,
      'lectureNo': lectureNo,
      'teacherName': teacherName,
    };
  }

  factory ClassModel.fromMap(Map<String, dynamic> map, String id) {
    return ClassModel(
      id: id,
      className: map['className'] ?? '',
      branch: map['branch'] ?? '',
      section: map['section'] ?? '',
      lectureNo: map['lectureNo'] ?? '',
      teacherName: map['teacherName'] ?? '',
    );
  }
}
