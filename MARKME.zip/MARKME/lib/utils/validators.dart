class Validators {
  static String? validateNotEmpty(String value) {
    if (value.isEmpty) {
      return "Field cannot be empty";
    }
    return null;
  }

  static String? validatePhone(String value) {
    if (value.length != 10) {
      return "Enter valid 10-digit number";
    }
    return null;
  }

  static String? validateEmail(String value) {
    if (!value.contains("@")) {
      return "Enter valid email";
    }
    return null;
  }

  static String? validateDifferentPhones(String student, String parent) {
    if (student == parent) {
      return "Student & Parent numbers must differ";
    }
    return null;
  }
}
