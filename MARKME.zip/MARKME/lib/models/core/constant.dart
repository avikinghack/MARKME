class AppConstants {
  static const String appName = "MarkMe";

  // Firebase Collections
  static const String students = "students";
  static const String classes = "classes";
  static const String attendance = "attendance";
  static const String messages = "messages";

  // Default Values
  static const String present = "present";
  static const String absent = "absent";
}
