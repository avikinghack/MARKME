import 'package:flutter/material.dart';
import '../../service/attendance_service.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Reports")),
      body: FutureBuilder(
        future: AttendanceService.getAttendance(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            List data = snapshot.data ?? [];
            return ListView(
              children: data.map((e) {
                return ListTile(
                  title: Text(e['studentName']),
                  subtitle: Text(e['status']),
                );
              }).toList(),
            );
          }
        },
      ),
    );
  }
}
