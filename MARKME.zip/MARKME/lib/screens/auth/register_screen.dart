import 'package:flutter/material.dart';

import '../../service/auth_service.dart';
import '../../widgets/custom_input.dart';
import '../../widgets/premium_button.dart';

class RegisterScreen extends StatelessWidget {
  final email = TextEditingController();
  final password = TextEditingController();

  RegisterScreen({super.key});

  void register(BuildContext context) async {
    var user = await AuthService.register(email.text, password.text);
    if (user != null) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Register")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            CustomInput(hint: "Email", controller: email),
            CustomInput(
              hint: "Password",
              controller: password,
              isPassword: true,
            ),
            SizedBox(height: 20),
            PremiumButton(title: "Register", onTap: () => register(context)),
          ],
        ),
      ),
    );
  }
}
