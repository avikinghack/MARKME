import 'dart:io';

class FaceDetectionService {
  static Future<bool> detectFaceWithEyes(File img) async {
    // Your face detection logic

    return true;
  }
}
