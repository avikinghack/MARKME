import '../models/attendance_model.dart';
import 'firebase_service.dart';

class AttendanceService {
  static Future markAttendance(AttendanceModel attendance) async {
    await FirebaseService.db.collection('attendance').add(attendance.toMap());
  }

  static Future<List<AttendanceModel>> getAttendance() async {
    var snapshot = await FirebaseService.db.collection('attendance').get();

    return snapshot.docs.map((doc) {
      return AttendanceModel.fromMap(doc.data(), doc.id);
    }).toList();
  }
}
